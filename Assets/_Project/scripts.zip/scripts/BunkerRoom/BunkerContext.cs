using UnityEngine;

public sealed class BunkerContext : MonoBehaviour
{
    public static BunkerContext Instance { get; private set; }

    [field: SerializeField] public BunkerPanelManager Panels { get; private set; }
    [field: SerializeField] public BunkerNotificationManager Notifications { get; private set; }
    [field: SerializeField] public BunkerEventManager Events { get; private set; }
    [field: SerializeField] public BunkerShopService Shop { get; private set; }
    [field: SerializeField] public BunkerRunStarter RunStarter { get; private set; }
    [field: SerializeField] public BunkerContentRegistry ContentRegistry { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }
}