public enum BunkerStationType
{
    None = 0,
    CharacterSelection = 1,
    WeaponSelection = 2,
    Shop = 3,
    Map = 4,
    Upgrade = 5,
    StartRun = 6,
    Animation = 7,
    CustomEvent = 8
}